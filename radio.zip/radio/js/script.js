/* Author: 

*/
document.ondragstart = function () { return false; };
var track_pos = false,
    origY = 0,
    round_rotation = 0,
    mouse_dis = 0,
    verticalDirection = 1,
    horizontalDirection = 1,
    can_scroll = true,
    diviation = 5,
    rotation_degree = 30;
$(document).ready(function() {
//    $('#slides').css('width',$('#slides li:first-child').width() * $('#slides li').length + $('#slides li').width());
//    touch_div = $('#scroll_area').Touchable();
//    var step = parseInt($('#slides').css('width')) / 360;
    scroller = $('#scroller');
    scroller.css('rotate', '0deg');
    WIDTH = scroller.width();
    HEIGHT = scroller.height();
    CENTERX = scroller.position().left + WIDTH / 2;
    CENTERY = scroller.position().top + HEIGHT / 2;
    $(document).bind('mouseup mousemove scroll', function(evt) {
        switch (evt.type) {
            case 'mouseup':
                track_pos = false;
                break;
            case 'scroll':
                if ($('#scroll_area').is('.scrollable')) {
                    return false;
                }
                break;
            case 'mousemove':
                if (track_pos) {
                    setDirection(evt.pageX,evt.pageY);
                    mouse_dis = verticalDirection  *  (origY - evt.pageY);
                    mouse_dis = horizontalDirection *  (origX - evt.pageX);
                    //test with distance from center point
                    mouse_dis = horizontalDirection *  (origX - evt.pageX);
                    
                    if (mouse_dis != 0) {
//                        mouse_dis = mouse_dis / Math.abs(mouse_dis);
                        mouse_dis = calculateDeltaForce(evt);
                        console.log(verticalDirection*mouse_dis);
                        rotate_wheel(mouse_dis);
                    }
//                    origY = evt.pageY;
//                    origX = evt.pageX;
                }
                break;
        }
    });
    /*
    calculate delta  with applied force in percents
     */
    function calculateDeltaForce(evt){
         //distance mouse was dragged in px
        deltaX = (origX - evt.pageX);
        //distance from center of circe.
        //close is stonger,further is weaker
        forceX = WIDTH/2 - (CENTERX - origX);
        //calculate force as percentage
        forceX = forceX / (WIDTH/2) *  100;
        //calculate delta with applied force
        //Math.max to prevent force to be less then 1
        deltaForceX =  deltaX * Math.max(forceX,1);
        //normalize deltaforce, and change direction according to axis
        deltaForceX = Math.abs(parseInt(deltaForceX/100,10)) * verticalDirection;
        return deltaForceX;
    }
    function rotate_wheel(distance) {
        if (Math.abs(distance) <= WIDTH/2){
            round_rotation = distance;
        };
        cur_deg = parseInt(scroller.attr('data-transform').replace(/[^\d\-]/g, ""));

        deg = cur_deg + (round_rotation - cur_deg);
//        console.log(cur_deg, round_rotation);
        scroller.css('rotate', deg + 'deg');
//            round_rotation = 0;
    }
    function rotate_wheel2(direction) {
        round_rotation += direction;
        if (Math.abs(round_rotation) > diviation) {
            cur_deg = parseInt(scroller.attr('data-transform').replace(/[^\d\-]/g, ""));
            if (Math.abs(cur_deg) >= 360) cur_deg = 0;
            deg = cur_deg + direction * (rotation_degree / diviation);
            scroller.css('rotate', deg + 'deg');
            round_rotation = 0;
        }
    }
    function setDirection(x,y){
        if(y < CENTERY){
//            console.log('top half');
            horizontalDirection = -1;
        }else{
//            console.log('bottom half');
            horizontalDirection = 1;
        }
        if(x < CENTERX){
//            console.log('left half');
            verticalDirection = 1;
        }else{
//            console.log('right half');
            verticalDirection = -1;
        }
    }
    scroller.bind('mousedown mouseenter mouseleave mousewheel touchstart touchend touchmove', function(evt, delta) {
        switch (evt.type) {
            case 'mousedown':
                track_pos = true;
                origY = evt.pageY;
                origX = evt.pageX;
                setDirection(origX,origY);
                break;
            case 'mouseenter':
                $(this).addClass('scrollable');
                break;
            case 'mouseleave':
                $(this).removeClass('scrollable');
                break;
            case 'mousewheel':
                rotate_wheel(delta * diviation);
                evt.preventDefault();
                break;
            case 'touchmove':
                evt.preventDefault();
                up_x = evt.originalEvent.touches[0].pageY;
                delta = (down_x - up_x) / 2;
                rotate_wheel(delta);
                down_x = evt.originalEvent.touches[0].pageY;
                break;
            case 'touchstart':
                evt.preventDefault();
                down_x = evt.originalEvent.touches[0].pageY;
                break;
            case 'touchend':

                break;
        }

    });

//function rotate_wheel(direction){
//    console.log(round_rotation);
//     round_rotation = round_rotation * direction;
////    console.log(Math.abs(round_rotation_old - round_rotation));
//
//    if(Math.abs(round_rotation_old - round_rotation) > diviation){
//        arr_location = parseInt($('#arrow').css('left')) + direction;
//        slide_left = parseInt($('#slides').css('left')) * -1;
//        $('#scroller').css('rotate',round_rotation_old+'deg');
//        if(arr_location > 0 && arr_location < $('#dial').width()){
//            $('#arrow').css('left',arr_location);
//        }
//
//        $('#slides').css('left',parseInt($('#slides').css('left')) + direction * step/2 * -1 );
//        round_rotation_old = round_rotation;
//    }else{
//        round_rotation_old += round_rotation;
//    }
//}



    function move_radio(direction) {
        arr_location = diviation * direction;
        arr_location += parseInt($('#arrow').css('left'));
        if (arr_location > 0 && arr_location < $('#dial').width()) {
            $('#arrow').css('left', arr_location);
        }
    }
});



